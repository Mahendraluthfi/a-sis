#
# TABLE STRUCTURE FOR: sis_akun
#

DROP TABLE IF EXISTS `sis_akun`;

CREATE TABLE `sis_akun` (
  `id_akun` varchar(8) NOT NULL,
  `nama_akun` varchar(190) DEFAULT NULL,
  `jenis_akun` varchar(10) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`id_akun`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('101', 'Kas', 'Aset', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('201', 'Tanah', 'Aset', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('210', 'Gedung', 'Aset', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('400', 'Utang Usaha', 'Kewajiban', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('450 ', 'Utang Pajak', 'Kewajiban', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('600', 'Modal', 'Modal', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('700', 'Pendapatan', 'Pendapatan', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('800', 'Beban Gaji', 'Beban', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('802', 'Beban Listrik', 'Beban', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('803', 'Beban Telepon', 'Beban', '1');
INSERT INTO `sis_akun` (`id_akun`, `nama_akun`, `jenis_akun`, `status`) VALUES ('805', 'Beban Lain-Lain', 'Beban', '1');


#
# TABLE STRUCTURE FOR: sis_alokasiguru
#

DROP TABLE IF EXISTS `sis_alokasiguru`;

CREATE TABLE `sis_alokasiguru` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_guru` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_alokasimapel
#

DROP TABLE IF EXISTS `sis_alokasimapel`;

CREATE TABLE `sis_alokasimapel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mapel` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kelas` (`id_kelas`),
  CONSTRAINT `sis_alokasimapel_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `sis_kelas` (`id_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_anggota
#

DROP TABLE IF EXISTS `sis_anggota`;

CREATE TABLE `sis_anggota` (
  `id_anggota` varchar(10) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `tgl_daftar` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_anggota`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_buku
#

DROP TABLE IF EXISTS `sis_buku`;

CREATE TABLE `sis_buku` (
  `id_buku` varchar(50) NOT NULL,
  `id_rak` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `pengarang` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `tahun_terbit` varchar(4) NOT NULL,
  `jml_buku` int(11) NOT NULL,
  `status` enum('AKTIF','NONAKTIF') NOT NULL DEFAULT 'AKTIF',
  PRIMARY KEY (`id_buku`),
  KEY `id_rak` (`id_rak`),
  KEY `id_kategori` (`id_kategori`),
  CONSTRAINT `sis_buku_ibfk_1` FOREIGN KEY (`id_rak`) REFERENCES `sis_rakbuku` (`id_rak`),
  CONSTRAINT `sis_buku_ibfk_2` FOREIGN KEY (`id_kategori`) REFERENCES `sis_kategoribuku` (`id_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_daftar
#

DROP TABLE IF EXISTS `sis_daftar`;

CREATE TABLE `sis_daftar` (
  `id_daftar` int(11) NOT NULL AUTO_INCREMENT,
  `no_reg` varchar(100) NOT NULL,
  `id_angkatan` int(11) DEFAULT NULL,
  `id_jenjang` int(11) DEFAULT NULL,
  `tgl_daftar` date DEFAULT NULL,
  `nisn` varchar(10) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `jekel` enum('L','P') DEFAULT NULL,
  `tempat_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `agama` varchar(50) DEFAULT NULL,
  `alamat_tinggal` text,
  `wn` varchar(255) DEFAULT NULL,
  `anak_ke` int(11) DEFAULT NULL,
  `sdr_kandung` int(11) DEFAULT NULL,
  `sdr_angkat` int(11) DEFAULT NULL,
  `alamat_domisili` text,
  `telepon` varchar(255) DEFAULT NULL,
  `tinggal_dengan` varchar(255) DEFAULT NULL,
  `gol_darah` varchar(5) DEFAULT NULL,
  `penyakit` varchar(255) DEFAULT NULL,
  `tinggi` int(11) DEFAULT NULL,
  `berat` int(11) DEFAULT NULL,
  `foto` text,
  `ayah` varchar(100) NOT NULL,
  `ibu` varchar(100) NOT NULL,
  `wali` varchar(100) NOT NULL,
  `alamat_orangtua` text NOT NULL,
  `alamat_wali` text NOT NULL,
  `pendapatan` varchar(100) NOT NULL,
  `diterima` varchar(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id_daftar`),
  KEY `id_angkatan` (`id_angkatan`),
  KEY `id_jenjang` (`id_jenjang`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('1', '0110180001', '1', '1', '2018-10-01', '', 'Andi Firmansyah', 'L', 'Kudus', '1996-08-16', '', '', 'WNI', '1', '0', '0', '', '', NULL, '', '', '0', '0', '', '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('2', '0110180002', '1', '1', '2018-10-01', '', 'Mail', 'L', 'Kudus', '2000-12-29', '', '', 'WNI', '1', '0', '0', '', '', NULL, '', '', '0', '0', '', '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('5', '2510180001', '1', '1', '2018-10-25', '', 'Andir', 'L', 'a', '2000-09-09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('6', '2510180001', '1', '1', '2018-10-25', '', 'Indra', 'P', 's', '2000-09-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('7', '2910180001', '1', '1', '2018-10-29', '', 'Andira', 'L', 'Kudus', '2000-09-09', '', '', NULL, '0', '0', '0', '', '', NULL, '', '', '0', '0', NULL, '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('8', '2910180001', '1', '1', '2018-10-29', '', 'Indra', 'P', 'Semarang', '2000-09-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('9', '2910180001', '1', '1', '2018-10-29', '', 'Ali', 'L', 'Semarang', '2000-09-11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('10', '2910180001', '1', '1', '2018-10-29', '', 'Isna', 'P', 'Semarang', '2000-09-12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'C');
INSERT INTO `sis_daftar` (`id_daftar`, `no_reg`, `id_angkatan`, `id_jenjang`, `tgl_daftar`, `nisn`, `nama`, `jekel`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_tinggal`, `wn`, `anak_ke`, `sdr_kandung`, `sdr_angkat`, `alamat_domisili`, `telepon`, `tinggal_dengan`, `gol_darah`, `penyakit`, `tinggi`, `berat`, `foto`, `ayah`, `ibu`, `wali`, `alamat_orangtua`, `alamat_wali`, `pendapatan`, `diterima`) VALUES ('11', '2910180001', '1', '1', '2018-10-29', '', 'Fuad', 'L', 'Semarang', '2000-09-13', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'C');


#
# TABLE STRUCTURE FOR: sis_denda
#

DROP TABLE IF EXISTS `sis_denda`;

CREATE TABLE `sis_denda` (
  `id_denda` int(11) NOT NULL,
  `denda` int(11) DEFAULT NULL,
  `max` int(6) NOT NULL,
  PRIMARY KEY (`id_denda`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sis_denda` (`id_denda`, `denda`, `max`) VALUES ('1', '1000', '5');


#
# TABLE STRUCTURE FOR: sis_det_peminjaman
#

DROP TABLE IF EXISTS `sis_det_peminjaman`;

CREATE TABLE `sis_det_peminjaman` (
  `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT,
  `no_peminjaman` varchar(100) NOT NULL,
  `id_detailbuku` varchar(20) NOT NULL,
  `denda` int(11) NOT NULL,
  `status` enum('PROSES','SELESAI') NOT NULL DEFAULT 'PROSES',
  PRIMARY KEY (`id_peminjaman`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_detail_angsur
#

DROP TABLE IF EXISTS `sis_detail_angsur`;

CREATE TABLE `sis_detail_angsur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_angsur` int(11) DEFAULT NULL,
  `id_tf` varchar(20) DEFAULT NULL,
  `cicilan` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_detailbuku
#

DROP TABLE IF EXISTS `sis_detailbuku`;

CREATE TABLE `sis_detailbuku` (
  `id_detailbuku` varchar(50) NOT NULL,
  `id_buku` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `ava` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_detailbuku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_guru
#

DROP TABLE IF EXISTS `sis_guru`;

CREATE TABLE `sis_guru` (
  `kode_guru` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(10) DEFAULT NULL,
  `nama_guru` varchar(50) DEFAULT NULL,
  `jekel` enum('L','P') DEFAULT NULL,
  `no_hp` varchar(14) DEFAULT NULL,
  `alamat` text,
  `status` enum('AKTIF','NONAKTIF') DEFAULT 'AKTIF',
  PRIMARY KEY (`kode_guru`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_isipaket
#

DROP TABLE IF EXISTS `sis_isipaket`;

CREATE TABLE `sis_isipaket` (
  `id_isi` int(11) NOT NULL AUTO_INCREMENT,
  `id_paket` int(11) NOT NULL,
  `nama_isi` varchar(20) NOT NULL,
  PRIMARY KEY (`id_isi`),
  KEY `id_paket` (`id_paket`),
  CONSTRAINT `sis_isipaket_ibfk_1` FOREIGN KEY (`id_paket`) REFERENCES `sis_paketjenjang` (`id_paket`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('1', '1', 'Kelas 1');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('2', '1', 'Kelas 2');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('3', '1', 'Kelas 3');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('4', '1', 'Kelas 4');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('5', '1', 'Kelas 5');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('6', '1', 'Kelas 6');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('7', '2', 'Kelas VII');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('8', '2', 'Kelas VIII');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('9', '2', 'Kelas IX');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('10', '3', 'Kelas X');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('11', '3', 'Kelas XI');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('12', '3', 'Kelas XII');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('13', '4', 'Kelas X');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('14', '4', 'Kelas XI');
INSERT INTO `sis_isipaket` (`id_isi`, `id_paket`, `nama_isi`) VALUES ('15', '4', 'Kelas XII');


#
# TABLE STRUCTURE FOR: sis_jenis_transaksi
#

DROP TABLE IF EXISTS `sis_jenis_transaksi`;

CREATE TABLE `sis_jenis_transaksi` (
  `id` varchar(20) NOT NULL,
  `nm_jenis_trans` varchar(200) NOT NULL,
  `rencana_anggaran` varchar(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `jenis_trans` enum('m','k') NOT NULL,
  `nominal` bigint(100) NOT NULL,
  `debit` varchar(10) NOT NULL,
  `kredit` varchar(10) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_jenisbayar
#

DROP TABLE IF EXISTS `sis_jenisbayar`;

CREATE TABLE `sis_jenisbayar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_jenis` varchar(3) DEFAULT NULL,
  `nama_jenis` varchar(25) DEFAULT NULL,
  `tipe_jenis` int(1) DEFAULT NULL,
  `ket` text,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_jenismapel
#

DROP TABLE IF EXISTS `sis_jenismapel`;

CREATE TABLE `sis_jenismapel` (
  `id_jenismapel` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jenismapel` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('AKTIF','NONAKTIF') NOT NULL DEFAULT 'AKTIF',
  PRIMARY KEY (`id_jenismapel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_jenjang
#

DROP TABLE IF EXISTS `sis_jenjang`;

CREATE TABLE `sis_jenjang` (
  `id_jenjang` int(11) NOT NULL AUTO_INCREMENT,
  `kd_jenjang` varchar(50) NOT NULL,
  `nama_jenjang` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `paket` varchar(2) NOT NULL,
  `aktif` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_jenjang`),
  KEY `id_jenjang` (`id_jenjang`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `sis_jenjang` (`id_jenjang`, `kd_jenjang`, `nama_jenjang`, `keterangan`, `paket`, `aktif`) VALUES ('1', 'SD', 'Sekolah Dasar', '', '1', '1');


#
# TABLE STRUCTURE FOR: sis_jurnal
#

DROP TABLE IF EXISTS `sis_jurnal`;

CREATE TABLE `sis_jurnal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_transaksi` varchar(15) DEFAULT NULL,
  `akun` varchar(10) DEFAULT NULL,
  `debet` bigint(100) DEFAULT NULL,
  `kredit` bigint(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_kategoribuku
#

DROP TABLE IF EXISTS `sis_kategoribuku`;

CREATE TABLE `sis_kategoribuku` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(25) NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_kelas
#

DROP TABLE IF EXISTS `sis_kelas`;

CREATE TABLE `sis_kelas` (
  `id_kelas` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenjang` int(11) NOT NULL,
  `nama_kelas` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('AKTIF','NONAKTIF','','') NOT NULL DEFAULT 'AKTIF',
  PRIMARY KEY (`id_kelas`),
  KEY `id_jenjang` (`id_jenjang`),
  CONSTRAINT `sis_kelas_ibfk_1` FOREIGN KEY (`id_jenjang`) REFERENCES `sis_jenjang` (`id_jenjang`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('1', '1', 'Kelas 1', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('2', '1', 'Kelas 2', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('3', '1', 'Kelas 3', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('4', '1', 'Kelas 4', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('5', '1', 'Kelas 5', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('6', '1', 'Kelas 6', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('7', '1', 'Kelas 1', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('8', '1', 'Kelas 2', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('9', '1', 'Kelas 3', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('10', '1', 'Kelas 4', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('11', '1', 'Kelas 5', '', 'AKTIF');
INSERT INTO `sis_kelas` (`id_kelas`, `id_jenjang`, `nama_kelas`, `keterangan`, `status`) VALUES ('12', '1', 'Kelas 6', '', 'AKTIF');


#
# TABLE STRUCTURE FOR: sis_level
#

DROP TABLE IF EXISTS `sis_level`;

CREATE TABLE `sis_level` (
  `id_akses` varchar(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(20) NOT NULL,
  PRIMARY KEY (`id_akses`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sis_level` (`id_akses`, `username`, `password`, `level`) VALUES ('assalamah@gmail.com', 'Administrator', 'a4fd8e6fa9fbf9a6f2c99e7b70aa9ef2', 'administrator');


#
# TABLE STRUCTURE FOR: sis_lulus
#

DROP TABLE IF EXISTS `sis_lulus`;

CREATE TABLE `sis_lulus` (
  `id_daftar` int(11) NOT NULL,
  `id_rombel` int(11) NOT NULL,
  `tgl_lulus` date NOT NULL,
  PRIMARY KEY (`id_daftar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_mapel
#

DROP TABLE IF EXISTS `sis_mapel`;

CREATE TABLE `sis_mapel` (
  `id_mapel` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenismapel` int(11) NOT NULL,
  `nama_mapel` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('AKTIF','NONAKTIF') NOT NULL DEFAULT 'AKTIF',
  PRIMARY KEY (`id_mapel`),
  KEY `id_jenismapel` (`id_jenismapel`),
  CONSTRAINT `sis_mapel_ibfk_1` FOREIGN KEY (`id_jenismapel`) REFERENCES `sis_jenismapel` (`id_jenismapel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_modul
#

DROP TABLE IF EXISTS `sis_modul`;

CREATE TABLE `sis_modul` (
  `id_modul` int(11) NOT NULL AUTO_INCREMENT,
  `nama_modul` varchar(30) NOT NULL,
  `nama_span` varchar(50) NOT NULL,
  `glyphicon` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `ktg` int(11) NOT NULL,
  PRIMARY KEY (`id_modul`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('1', 'tahunajaran', 'Tahun Ajaran', 'fa fa-calendar-check-o', 'tahunajaran', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('2', 'jenjang', 'Jenjang', 'fa fa-th-large', 'jenjang', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('3', 'kelas', 'Kelas', 'fa fa-object-group', 'kelas', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('4', 'rombel', 'Rombongan Belajar', 'fa fa-object-ungroup', 'rombel', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('5', 'jenismapel', 'Jenis Mata Pelajaran', 'fa fa-file-text', 'jenismapel', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('6', 'mapel', 'Mata Pelajaran', 'fa fa-file-text', 'mapel', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('7', 'guru', 'Guru', 'fa fa-group', 'guru', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('8', 'daftar', 'Pendaftaran Siswa', 'fa fa-indent', 'daftar', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('9', 'pembagian', 'Pembagian Kelas', 'glyphicon glyphicon-indent-left', 'pembagian', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('10', 'siswa', 'Siswa', 'fa fa-users', 'siswa', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('11', 'rakbuku', 'Data Rak Buku', 'glyphicon glyphicon-th', 'rakbuku', '18');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('12', 'kategoribuku', 'Data Kategori', 'fa fa-bars', 'kategoribuku', '18');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('13', 'buku', 'Data Buku', 'fa fa-book', 'buku', '18');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('14', 'anggota', 'Data Anggota', 'fa fa-group', 'anggota', '18');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('15', 'peminjaman', 'Peminjaman', 'fa fa-share', 'peminjaman', '18');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('16', 'pengembalian', 'Pengembalian', 'fa fa-reply', 'pengembalian', '18');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('17', 'akademik', 'Akademik', 'glyphicon glyphicon-education', '#', '0');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('18', 'perpustakaan', 'Perpustakaan', 'glyphicon glyphicon-book', '#', '0');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('19', 'nilai', 'Nilai Siswa', 'glyphicon glyphicon-list-alt', '#', '0');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('20', 'inputnilai', 'Input Nilai', 'glyphicon glyphicon-plus-sign', 'nilai', '19');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('21', 'datanilai', 'Data Nilai', 'glyphicon glyphicon-floppy-disk', 'datanilai', '19');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('22', 'cetaknilai', 'Cetak Raport', 'glyphicon glyphicon-print\r\n', 'cetaknilai', '19');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('23', 'keuangan', 'Keuangan', 'fa fa-dollar', '#', '0');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('25', 'mutasi', 'Mutasi Siswa', 'fa fa-random', 'mutasi', '17');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('26', 'rencana', 'Rencana Anggaran', 'glyphicon glyphicon-tasks', 'rencana', '23');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('27', 'akun', 'Akun', 'glyphicon glyphicon-asterisk', 'akun', '23');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('28', 'inputdana', 'Input Dana Masuk / Keluar', 'glyphicon glyphicon-arrow-right', 'inputdana', '23');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('29', 'jurnal', 'Entri Jurnal', 'glyphicon glyphicon-import', 'jurnal', '23');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('32', 'lapjurnal', 'Laporan Jurnal', 'glyphicon glyphicon-book', 'lapjurnal', '23');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('33', 'lapbukubesar', 'Laporan Buku Besar', 'glyphicon glyphicon-book', 'lapbukubesar', '23');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('34', 'lapneraca', 'Laporan Neraca Lajur', 'glyphicon glyphicon-book', 'lapneraca', '23');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('35', 'laperpus', 'Laporan', 'glyphicon glyphicon-book', 'laperpus', '18');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('36', 'pembayaran', 'Pembayaran', 'glyphicon glyphicon-briefcase', '#', '0');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('37', 'jenisbayar', 'Jenis Pembayaran', 'glyphicon glyphicon-tasks', 'jenisbayar', '36');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('38', 'pilihbayar', 'Pilihan Pembayaran', 'glyphicon glyphicon-option-vertical', 'pilihbayar', '36');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('39', 'setbayar', 'Set Pembayaran', 'glyphicon glyphicon-cog', 'setbayar', '36');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('40', 'inputbayar', 'Input Pembayaran', 'glyphicon glyphicon-log-in', 'inputbayar', '36');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('41', 'tabungan', 'Tabungan', 'glyphicon glyphicon-credit-card', 'tabungan', '36');
INSERT INTO `sis_modul` (`id_modul`, `nama_modul`, `nama_span`, `glyphicon`, `url`, `ktg`) VALUES ('42', 'lapbayar', 'Laporan Pembayaran', 'glyphicon glyphicon-file', 'lapbayar', '36');


#
# TABLE STRUCTURE FOR: sis_nilai
#

DROP TABLE IF EXISTS `sis_nilai`;

CREATE TABLE `sis_nilai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_rombel` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_angkatan` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `nuh1` int(11) NOT NULL,
  `nuh2` int(11) NOT NULL,
  `nuh3` int(11) NOT NULL,
  `nt1` int(11) NOT NULL,
  `nt2` int(11) NOT NULL,
  `nt3` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `smt` int(11) NOT NULL,
  `rnuh` int(11) NOT NULL,
  `rnt` int(11) NOT NULL,
  `nh` int(11) NOT NULL,
  `nar` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_paketjenjang
#

DROP TABLE IF EXISTS `sis_paketjenjang`;

CREATE TABLE `sis_paketjenjang` (
  `id_paket` int(11) NOT NULL AUTO_INCREMENT,
  `kode_paket` varchar(10) NOT NULL,
  `nama_paket` varchar(100) NOT NULL,
  PRIMARY KEY (`id_paket`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `sis_paketjenjang` (`id_paket`, `kode_paket`, `nama_paket`) VALUES ('1', 'SD', 'Sekolah Dasar');
INSERT INTO `sis_paketjenjang` (`id_paket`, `kode_paket`, `nama_paket`) VALUES ('2', 'SMP', 'Sekolah Menengah Pertama');
INSERT INTO `sis_paketjenjang` (`id_paket`, `kode_paket`, `nama_paket`) VALUES ('3', 'SMA', 'Sekolah Menengah Atas');
INSERT INTO `sis_paketjenjang` (`id_paket`, `kode_paket`, `nama_paket`) VALUES ('4', 'SMK', 'Sekolah Menengah Kejuruan');


#
# TABLE STRUCTURE FOR: sis_pembayaran
#

DROP TABLE IF EXISTS `sis_pembayaran`;

CREATE TABLE `sis_pembayaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tf` varchar(20) DEFAULT NULL,
  `date` date NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_ta` int(11) DEFAULT NULL,
  `id_jenis` int(11) DEFAULT NULL,
  `bayar` int(11) DEFAULT NULL,
  `ket` text,
  `cek_p` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_peminjaman
#

DROP TABLE IF EXISTS `sis_peminjaman`;

CREATE TABLE `sis_peminjaman` (
  `no_peminjaman` varchar(100) NOT NULL,
  `id_anggota` varchar(10) NOT NULL,
  `datestamp` date NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `status` enum('PROSES','SELESAI') NOT NULL DEFAULT 'PROSES',
  PRIMARY KEY (`no_peminjaman`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_pilihanbayar
#

DROP TABLE IF EXISTS `sis_pilihanbayar`;

CREATE TABLE `sis_pilihanbayar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_ta` int(11) DEFAULT NULL,
  `nama_pilihan` varchar(50) DEFAULT NULL,
  `opsi_a` int(11) DEFAULT NULL,
  `opsi_b` int(11) DEFAULT NULL,
  `opsi_c` int(11) DEFAULT NULL,
  `opsi_d` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `save` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_pindah
#

DROP TABLE IF EXISTS `sis_pindah`;

CREATE TABLE `sis_pindah` (
  `id_daftar` int(11) NOT NULL,
  `id_rombel` int(11) NOT NULL,
  `nm_sekolah` text NOT NULL,
  PRIMARY KEY (`id_daftar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_pmb_angsur
#

DROP TABLE IF EXISTS `sis_pmb_angsur`;

CREATE TABLE `sis_pmb_angsur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) DEFAULT NULL,
  `id_ta` int(11) DEFAULT NULL,
  `id_jenis` int(11) DEFAULT NULL,
  `tagihan` int(11) DEFAULT NULL,
  `sisa` int(11) DEFAULT NULL,
  `tipe` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_pmb_rutin
#

DROP TABLE IF EXISTS `sis_pmb_rutin`;

CREATE TABLE `sis_pmb_rutin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) DEFAULT NULL,
  `id_ta` int(11) DEFAULT NULL,
  `id_jenis` int(11) DEFAULT NULL,
  `tagihan` int(11) DEFAULT NULL,
  `Jul` varchar(20) DEFAULT NULL,
  `Agt` varchar(20) DEFAULT NULL,
  `Sep` varchar(20) DEFAULT NULL,
  `Okt` varchar(20) DEFAULT NULL,
  `Nov` varchar(20) DEFAULT NULL,
  `Des` varchar(20) DEFAULT NULL,
  `Jan` varchar(20) DEFAULT NULL,
  `Feb` varchar(20) DEFAULT NULL,
  `Mar` varchar(20) DEFAULT NULL,
  `Apr` varchar(20) DEFAULT NULL,
  `Mei` varchar(20) DEFAULT NULL,
  `Jun` varchar(20) DEFAULT NULL,
  `tipe` int(11) DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_privilage
#

DROP TABLE IF EXISTS `sis_privilage`;

CREATE TABLE `sis_privilage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_akses` varchar(50) NOT NULL,
  `id_modul` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('1', 'assalamah@gmail.com', '1');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('2', 'assalamah@gmail.com', '2');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('3', 'assalamah@gmail.com', '3');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('4', 'assalamah@gmail.com', '4');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('5', 'assalamah@gmail.com', '5');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('6', 'assalamah@gmail.com', '6');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('7', 'assalamah@gmail.com', '7');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('8', 'assalamah@gmail.com', '8');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('9', 'assalamah@gmail.com', '9');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('10', 'assalamah@gmail.com', '10');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('11', 'assalamah@gmail.com', '11');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('12', 'assalamah@gmail.com', '12');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('13', 'assalamah@gmail.com', '13');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('14', 'assalamah@gmail.com', '14');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('15', 'assalamah@gmail.com', '15');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('16', 'assalamah@gmail.com', '16');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('17', 'assalamah@gmail.com', '17');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('18', 'assalamah@gmail.com', '18');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('19', 'assalamah@gmail.com', '19');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('20', 'assalamah@gmail.com', '20');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('21', 'assalamah@gmail.com', '21');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('22', 'assalamah@gmail.com', '22');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('23', 'assalamah@gmail.com', '23');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('24', 'assalamah@gmail.com', '25');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('25', 'assalamah@gmail.com', '26');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('26', 'assalamah@gmail.com', '27');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('27', 'assalamah@gmail.com', '28');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('28', 'assalamah@gmail.com', '29');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('29', 'assalamah@gmail.com', '32');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('30', 'assalamah@gmail.com', '33');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('31', 'assalamah@gmail.com', '34');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('32', 'assalamah@gmail.com', '35');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('33', 'assalamah@gmail.com', '36');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('34', 'assalamah@gmail.com', '37');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('35', 'assalamah@gmail.com', '38');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('36', 'assalamah@gmail.com', '39');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('37', 'assalamah@gmail.com', '40');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('38', 'assalamah@gmail.com', '41');
INSERT INTO `sis_privilage` (`id`, `id_akses`, `id_modul`) VALUES ('39', 'assalamah@gmail.com', '42');


#
# TABLE STRUCTURE FOR: sis_rakbuku
#

DROP TABLE IF EXISTS `sis_rakbuku`;

CREATE TABLE `sis_rakbuku` (
  `id_rak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_rak` varchar(25) NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_rak`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_reg_user
#

DROP TABLE IF EXISTS `sis_reg_user`;

CREATE TABLE `sis_reg_user` (
  `id_reg` varchar(100) NOT NULL,
  `date_reg` date NOT NULL,
  `nama_sekolah` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `notelp` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` text NOT NULL,
  PRIMARY KEY (`id_reg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `sis_reg_user` (`id_reg`, `date_reg`, `nama_sekolah`, `alamat`, `notelp`, `email`, `logo`) VALUES ('a4fd8e6fa9fbf9a6f2c99e7b70aa9ef2-2018-10-29', '2018-10-29', 'Yayasan Assalamah', 'Jl. Gatot Subroto', '0247777', 'assalamah@gmail.com', '');


#
# TABLE STRUCTURE FOR: sis_rencana_anggaran
#

DROP TABLE IF EXISTS `sis_rencana_anggaran`;

CREATE TABLE `sis_rencana_anggaran` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `nm_anggaran` varchar(150) NOT NULL,
  `awal_periode` date NOT NULL,
  `akhir_periode` date NOT NULL,
  `pencatat` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `tetapkan` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_rombel
#

DROP TABLE IF EXISTS `sis_rombel`;

CREATE TABLE `sis_rombel` (
  `id_rombel` int(11) NOT NULL AUTO_INCREMENT,
  `id_kelas` int(11) NOT NULL,
  `nama_rombel` varchar(100) NOT NULL,
  `kuota` int(11) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `status` enum('AKTIF','NONAKTIF','','') NOT NULL DEFAULT 'AKTIF',
  PRIMARY KEY (`id_rombel`),
  KEY `id_kelas` (`id_kelas`),
  CONSTRAINT `sis_rombel_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `sis_kelas` (`id_kelas`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `sis_rombel` (`id_rombel`, `id_kelas`, `nama_rombel`, `kuota`, `nip`, `status`) VALUES ('1', '1', 'SD 1 A', '35', '0', 'AKTIF');


#
# TABLE STRUCTURE FOR: sis_siswa
#

DROP TABLE IF EXISTS `sis_siswa`;

CREATE TABLE `sis_siswa` (
  `id_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) NOT NULL,
  `id_daftar` int(11) NOT NULL,
  `id_rombel` int(11) NOT NULL,
  `saldo_tabungan` int(14) NOT NULL,
  PRIMARY KEY (`id_siswa`),
  KEY `id_daftar` (`id_daftar`),
  KEY `id_rombel` (`id_rombel`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `sis_siswa` (`id_siswa`, `nis`, `id_daftar`, `id_rombel`, `saldo_tabungan`) VALUES ('1', '18.001', '7', '1', '0');
INSERT INTO `sis_siswa` (`id_siswa`, `nis`, `id_daftar`, `id_rombel`, `saldo_tabungan`) VALUES ('2', '18.002', '8', '1', '0');
INSERT INTO `sis_siswa` (`id_siswa`, `nis`, `id_daftar`, `id_rombel`, `saldo_tabungan`) VALUES ('3', '18.003', '9', '1', '0');
INSERT INTO `sis_siswa` (`id_siswa`, `nis`, `id_daftar`, `id_rombel`, `saldo_tabungan`) VALUES ('4', '18.004', '10', '1', '0');
INSERT INTO `sis_siswa` (`id_siswa`, `nis`, `id_daftar`, `id_rombel`, `saldo_tabungan`) VALUES ('5', '18.005', '11', '1', '0');


#
# TABLE STRUCTURE FOR: sis_tabungandetail
#

DROP TABLE IF EXISTS `sis_tabungandetail`;

CREATE TABLE `sis_tabungandetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tf` varchar(20) DEFAULT NULL,
  `date` date NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_ta` int(11) DEFAULT NULL,
  `debit` int(11) DEFAULT NULL,
  `kredit` int(11) DEFAULT NULL,
  `saldo_r` int(11) DEFAULT NULL,
  `ket` text,
  `cek_p` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_tagihan
#

DROP TABLE IF EXISTS `sis_tagihan`;

CREATE TABLE `sis_tagihan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) NOT NULL,
  `nm_tagihan` varchar(50) NOT NULL,
  `tagihan` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sis_tahunajaran
#

DROP TABLE IF EXISTS `sis_tahunajaran`;

CREATE TABLE `sis_tahunajaran` (
  `id_angkatan` int(11) NOT NULL AUTO_INCREMENT,
  `kd_angkatan` varchar(15) NOT NULL,
  `nama_angkatan` varchar(20) NOT NULL,
  `keterangan` text NOT NULL,
  `tgl_a` date NOT NULL,
  `tgl_b` date NOT NULL,
  `aktif` int(11) NOT NULL,
  `status` enum('AKTIF','NONAKTIF') NOT NULL DEFAULT 'AKTIF',
  PRIMARY KEY (`id_angkatan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `sis_tahunajaran` (`id_angkatan`, `kd_angkatan`, `nama_angkatan`, `keterangan`, `tgl_a`, `tgl_b`, `aktif`, `status`) VALUES ('1', 'TA18/19', 'Tahun Ajaran 2018/20', '', '2018-07-01', '2019-06-30', '1', 'AKTIF');


#
# TABLE STRUCTURE FOR: sis_transaksi
#

DROP TABLE IF EXISTS `sis_transaksi`;

CREATE TABLE `sis_transaksi` (
  `id` varchar(15) NOT NULL,
  `waktu` datetime DEFAULT NULL,
  `id_jenis_transaksi` varchar(15) DEFAULT NULL,
  `idr` int(11) NOT NULL,
  `pencatat` varchar(20) DEFAULT NULL,
  `uraian` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

